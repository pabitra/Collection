﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConcodanceApp.Model
{
    public class TextStore
    {
        public int LineNo { get; set; }
        public string Sentence { get; set; }
    }
}
