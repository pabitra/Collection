﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConcodanceApp.Model
{
    public class FirstLevelData
    {
        public string SentenceIndex { get; set; }
        public string Word { get; set; }
        public int WordCountPerSentence { get; set; }
    }
}
