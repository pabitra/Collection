namespace ConcodanceApp.Common
{
    public interface ITextCleaningService
    {
        string FilterSourceText(string currentString);

        

    }
}